#!/usr/bin/env python3
"""HTTP wrapper around `autoshorts.py stream` so the Netlify page can drive it.

Endpoints (all need header  X-API-Key: <APP_TOKEN>):
  POST /api/jobs                  {urls:[...], live_seconds?, reframe?, max_clips?}  -> {id}
  GET  /api/jobs/{id}             -> {status, log, result}
  GET  /api/clips/{slug}/{file}   -> the rendered clip (also accepts ?key=<APP_TOKEN> for <video> tags)

It never publishes to social media: approval + publishing stay in the CLI / agent (SKILL.md).
Env: APP_TOKEN (required), ALLOWED_ORIGIN (your Netlify URL, default "*"), plus the usual .env keys.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import tempfile
import threading
import uuid
from pathlib import Path

from dotenv import load_dotenv
from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")

APP_TOKEN = os.getenv("APP_TOKEN", "")
if not APP_TOKEN:
    raise SystemExit("APP_TOKEN is not set. Choose a long random string and set it in the environment.")

OUTPUT_FOLDER = Path(os.getenv("OUTPUT_FOLDER", ROOT / "output")).expanduser().resolve()
URL_RE = re.compile(r"^https?://\S+$")

app = FastAPI(title="autoshorts API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[os.getenv("ALLOWED_ORIGIN", "*")],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

JOBS: dict[str, dict] = {}
RUN_LOCK = threading.Lock()  # one heavy job at a time (Whisper + ffmpeg are CPU hungry)


def auth(x_api_key: str | None = Header(default=None), key: str | None = Query(default=None)) -> None:
    if (x_api_key or key) != APP_TOKEN:
        raise HTTPException(401, "bad or missing API key")


class JobIn(BaseModel):
    urls: list[str]
    live_seconds: int | None = None
    reframe: str = "blur"
    max_clips: int = 15


def run_job(job_id: str, body: JobIn) -> None:
    job = JOBS[job_id]
    with RUN_LOCK:
        job["status"] = "running"
        cmd = [sys.executable, str(ROOT / "autoshorts.py"), "stream", *body.urls,
               "--reframe", body.reframe, "--max-clips", str(body.max_clips)]
        if body.live_seconds:
            cmd += ["--live-seconds", str(body.live_seconds)]
        with tempfile.TemporaryFile("w+") as out:
            proc = subprocess.Popen(cmd, cwd=ROOT, stdout=out, stderr=subprocess.PIPE, text=True)
            for line in proc.stderr:  # type: ignore[union-attr]
                job["log"].append(line.rstrip())
                job["log"] = job["log"][-200:]
            proc.wait()
            out.seek(0)
            raw = out.read()
        try:
            result = json.loads(raw)
        except json.JSONDecodeError:
            result = []
        for item in result:
            for clip in item.get("clips", []) or []:
                f = clip.get("file")
                if f:
                    clip["url"] = f"/api/clips/{Path(f).parent.name}/{Path(f).name}"
                    clip.pop("file", None)
            item.pop("source_video", None)
            item.pop("output_dir", None)
        job["result"] = result
        job["status"] = "done" if proc.returncode == 0 and not any(r.get("error") for r in result) else "error"


@app.post("/api/jobs", dependencies=[Depends(auth)])
def create_job(body: JobIn) -> dict:
    urls = [u.strip() for u in body.urls if URL_RE.match(u.strip())]
    if not urls:
        raise HTTPException(400, "no valid http(s) URLs")
    if body.reframe not in {"blur", "crop", "none"}:
        raise HTTPException(400, "bad reframe")
    body.urls = urls
    body.max_clips = max(0, min(body.max_clips, 30))
    job_id = uuid.uuid4().hex[:12]
    JOBS[job_id] = {"status": "queued", "log": [], "result": None}
    threading.Thread(target=run_job, args=(job_id, body), daemon=True).start()
    return {"id": job_id}


@app.get("/api/jobs/{job_id}", dependencies=[Depends(auth)])
def get_job(job_id: str) -> dict:
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "unknown job")
    return {"status": job["status"], "log": job["log"][-40:], "result": job["result"]}


@app.get("/api/clips/{slug}/{filename}", dependencies=[Depends(auth)])
def get_clip(slug: str, filename: str):
    path = (OUTPUT_FOLDER / slug / filename).resolve()
    if OUTPUT_FOLDER not in path.parents or path.suffix.lower() not in {".mp4", ".png"} or not path.is_file():
        raise HTTPException(404, "not found")
    return FileResponse(path)


@app.get("/health")
def health() -> dict:
    return {"ok": True}
